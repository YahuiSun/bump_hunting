#pragma once


double min_double(std::list<double> numbers) {

	double min = *numbers.begin();

	for (auto it = numbers.begin(); it != numbers.end(); it++) {
		if (min > *it) {
			min = *it;
		}
	}

	return min;

}

